<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>1. Cálculo de salário</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

    <!-- Você foi contratado para desenvolver um sistema para a empresa TechSoft que calcula o salário final de um funcionário. -->

    <body>
        <h1 class="text-center mt-5">CÁLCULO DE SALÁRIO</h1>

        </br> <!-- < pula linha -->

        <?php

        $salario1 = 2500;
        $bonus = 420;
        $salariof = ($salario1+$bonus);
    
        echo "O salário base é de R$ {$salario1}, e o bônus é de R$ {$bonus}. ";
        echo "Sendo assim, o salário final do funcionário é: R$ {$salariof}.";
        ?>

    </body>

</html>