<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>5. Sistema meteorológico</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você está desenvolvendo um sistema para uma estação meteorológica que convertetemperaturas (graus celsius para fahrenheit). -->

    <body>
        <h1 class="text-center mt-5">CONVERSÃO CELSIUS PARA FAHRENHEIT</h1>

        <?php
        $C = 30; // graus celsius
        $F = ($C*9/5)+32; // graus fahrenheit
    
        echo "A temperatura de {$C}°C corresponde a {$F}°F.";
        ?>

    </body>

</html>