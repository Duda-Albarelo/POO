<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>6. Sistema de cadastro de pessoas</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você foi contratado para desenvolver um sistema que calcula a idade das pessoas. -->
<!-- Para fazer COMENTÁRIO EM PHP, usa esse formato aqui !!!! -->

    <body>
        <h1 class="text-center mt-5">CADASTRO POR IDADE</h1>

        <?php
        $ano = 2026; // ano atual
        $nascimento = 30; // ano nascimento

        $idade = ($ano-$nascimento); 
    
        echo "A pessoa cadastrada possui {$idade} anos.";
        ?>

    </body>

</html>