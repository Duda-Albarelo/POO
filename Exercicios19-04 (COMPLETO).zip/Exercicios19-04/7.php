<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>7. Sistema de construção civil</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Uma empresa chamada Construtora Alpha precisa calcular a área de terrenos retangulares. -->

    <body>
        <h1 class="text-center mt-5">CÁLCULO DE ÁREA DE TERRENO</h1>

        <?php
        $base = 30; // em metros
        $altura = 50;

        $area = ($base*$altura); 
    
        echo "A área do terreno é de {$area} m².";
        ?>

    </body>

</html>