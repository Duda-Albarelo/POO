<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>8. Sistema de caixa de mercado</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você está desenvolvendo um sistema para um supermercado que calcula o troco das compras. -->

    <body>
        <h1 class="text-center mt-5">CÁLCULO DE TROCO</h1>

        <?php
        $valor = 30; // valor da compra
        $pagamento = 50;

        $troco = ($pagamento-$valor); 
    
        echo "Troco a ser devolvido: R$ {$troco}.";
        ?>

    </body>

</html>