<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>3. Sistema de notas (escola)</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você foi contratado por uma escola para criar um sistema que calcula a média final dos alunos.-->

    <body>
        <h1 class="text-center mt-5">CÁLCULO DE MÉDIA</h1>

        <?php
        $nota1 = 4;
        $nota2 = 9;
        $nota3 = 8;
        $media = ($nota1+$nota2+$nota3)/3;
    
        echo "A média final do aluno é: {$media}.";
        ?>

    </body>

</html>