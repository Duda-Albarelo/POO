<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>2. Consumo de veículos</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você está desenvolvendo um sistema para uma locadora chamada AutoRent quecalcula o consumo médio dos veículos. -->

    <body>
        <h1 class="text-center mt-5">CONSUMO MÉDIO DE VEÍCULOS</h1>
        
        </br>
        
        <?php
        $distancia = 20; // em km
        $comb_gasto = 2; // gasto em litros
        $consumo = ($distancia/$comb_gasto);
    
        echo "O veículo percorreu {$distancia} km, e consumiu {$comb_gasto} L de combustível. ";
        echo "O consumo médio do veículo foi de {$consumo} km/L";
        ?>

    </body>

</html>