<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>10. Desafio – sistema completo de venda</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Você está desenvolvendo um sistema para a loja MegaStore. -->


    <body>
        <h1 class="text-center mt-5">CÁLCULO DE DESCONTO (DESAFIO)</h1>

        <?php
        $cliente = "Claudete"; // nome
        $valor = 5130; // preço do produto
        $percento = 20; // percentual de desconto

        $desconto = $valor*($percento/100); // valor do desconto em si
        $valorf = ($valor-$desconto);  // valor final
    
        echo "Cliente {$cliente} comprou um produto de R$ {$valor}, recebeu R$ {$desconto} de desconto e pagará R$ {$valorf}";
        ?>

    </body>

</html>