<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>9. Sistema bancário (juros simples)</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

    <!-- Um banco precisa de um sistema para calcular o rendimento de aplicações -->

    <body>  
        <h1 class="text-center mt-5">CÁLCULO DE JUROS SIMPLES</h1>

        <?php
        
        $cap_inicial = 3500; // capital inicial
        $taxa = 2; // porcentagem de taxa de juros
        $tempo = 3; // em meses

        $juros = ($cap_inicial*$taxa*$tempo); 
    
        echo "O valor do juro gerado é de R$ {$juros}.";
        ?>

    </body>

</html>