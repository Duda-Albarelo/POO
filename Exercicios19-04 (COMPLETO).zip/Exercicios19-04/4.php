<!DOCTYPE html>
<html lang="en">
    
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>4. Sistema de vendas com desconto</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>

<!-- Uma loja chamada Loja Descontão precisa de um sistema para calcular o valor final de seus produtos com desconto. -->

    <body>
        <h1 class="text-center mt-5">VENDA COM DESCONTO</h1>

        <?php
        $valor = 146; // valor do produto em reais
        $percento = 30; // porcentagem de desconto

        $desconto = $valor*($percento/100);
        $valorf = ($valor-$desconto);
    
        echo "O produto custava R$ {$valor} e agora custa R$ {$valorf}.";
        ?>

    </body>

</html>